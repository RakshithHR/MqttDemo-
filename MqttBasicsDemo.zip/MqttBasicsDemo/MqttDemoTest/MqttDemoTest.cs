using ConsoleBroker;
using ConsolePublisher;
using ConsoleSubscriber;
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Protocol;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace MQTT.Test
{
    public class MqttDemoTest
    {

        private readonly Broker broker;
        private readonly Publisher publisher;
        private readonly Subscriber subscriber;

        public MqttDemoTest()
        {
            broker = new Broker();
            publisher = new Publisher();
            subscriber = new Subscriber();
        }

        [Fact]
        public async Task ValidateMessageDetails()
        {
            //Arrange
            // build event
            var count = 0;
            MqttApplicationMessage receivedMessage = null;
            var brokerOptions = broker.BuildServerOptions();
            var pubOptions = publisher.BuildClientOptions();
            var subOptions = subscriber.BuildClientOptions();

            //create event
            var brokerserver = broker.CreateServer();
            var pubClient = publisher.CreateClient();
            var subClient = subscriber.CreateClient();
            subClient = subscriber.ConnectHandler(subClient);
            subClient.UseApplicationMessageReceivedHandler(e => { receivedMessage = e.ApplicationMessage; count++; });

            //Act
            //start event
            await brokerserver.StartAsync(brokerOptions.Build());
            await subClient.ConnectAsync(subOptions.Build());
            await pubClient.ConnectAsync(pubOptions.Build());
            var message = publisher.SimulatePublish(pubClient, "Hello your first Mqtt messge recived");
            publisher.SimulatePublish(pubClient, "Hello your first Mqtt messge recived");
            await Task.Delay(10);
            await brokerserver.StopAsync();

            //Assert
            // validate event
            Assert.NotNull(receivedMessage);
            Assert.Equal("test", receivedMessage.Topic);
            Assert.Equal("Hello your first Mqtt messge recived", Encoding.UTF8.GetString(receivedMessage.Payload));
            Assert.Equal(2, count);
        }

    }
}
