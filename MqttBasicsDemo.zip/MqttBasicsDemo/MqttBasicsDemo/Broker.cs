﻿using MQTTnet;
using MQTTnet.Server;
using System;

namespace ConsoleBroker
{
    public class Broker
    {
        public static void Main(string[] args)
        {
            Broker broker = new();
            broker.ConnectMQTTBroker();
        }

        public string ConnectMQTTBroker(string message = null)
        {
            Console.WriteLine("----Start connecting Broker----");
            //configure options
            var optionsBuilder = BuildServerOptions();

            // creates a new mqtt server     
            IMqttServer mqttServer = CreateServer();
            mqttServer.StartAsync(optionsBuilder.Build()).Wait();
            Console.WriteLine($"Broker is Connected: Host: {mqttServer.Options.DefaultEndpointOptions.BoundInterNetworkAddress} Port: {mqttServer.Options.DefaultEndpointOptions.Port}");

            Console.ReadLine();
            return "success";
        }
        public IMqttServer CreateServer()
        {
            return new MqttFactory().CreateMqttServer();
        }

        public MqttServerOptionsBuilder BuildServerOptions()
        {
            return new MqttServerOptionsBuilder()
                                        // set endpoint to localhost
                                        .WithDefaultEndpoint()
                                        // port used will be 1883
                                        .WithDefaultEndpointPort(1883);
        }
    }
}
