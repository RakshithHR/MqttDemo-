﻿using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Client.Options;
using MQTTnet.Client.Subscribing;
using MQTTnet.Server;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsolePublisher
{
    public class Publisher
    {
        private static IMqttClient _client;
        private static MqttClientOptionsBuilder _options;
        
        static void Main(string[] args)
        {
            Publisher publisher = new Publisher();
            publisher.ConnectPublisher();
        }
        public void ConnectPublisher(string message = null)
        {

            Console.WriteLine("Starting Publisher.....");
            try
            {
                //Create a new MQTT Client
                _client = CreateClient();
                //configure options
                _options = BuildClientOptions();


                //handlers
                _client = ConnectHandler();

                //connect
                _client.ConnectAsync(_options.Build()).Wait();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("-----Publisher is Connected----");
                Console.WriteLine("Press key to publish message.");
                string val = string.Empty;
                if (message == null)
                {
                    val = Console.ReadLine();
                }
                else
                {
                    val = message;
                }
               
                var message1 = SimulatePublish(null, val);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Simulation ended! press any key to exit.");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }

        public IMqttClient CreateClient()
        {
            var factory = new MqttFactory();
            return factory.CreateMqttClient();
        }

        public MqttClientOptionsBuilder BuildClientOptions()
        {
           
            return new MqttClientOptionsBuilder()
                                .WithClientId("Pub_Id:1")
                                .WithTcpServer("localhost", port: 1883)
                                .WithCredentials(username: "Rakshith", password: "HPinvent11")
                                .WithCleanSession();
        }
        public IMqttClient ConnectHandler()
        {
            _client.UseConnectedHandler(async e =>
            {
                Console.WriteLine("### Connecting  with Broker ###");

                // Subscribe to a topic
                await _client.SubscribeAsync(new MqttClientSubscribeOptionsBuilder().WithTopicFilter("my/topic",MQTTnet.Protocol.MqttQualityOfServiceLevel.AtMostOnce).Build());

                Console.WriteLine("Device Subscribed");
            });
            _client.UseDisconnectedHandler(async e =>
            {
                Console.WriteLine("### Device disconnected from broker ###");
                await Task.Delay(TimeSpan.FromSeconds(5));

                try
                {
                    await _client.ConnectAsync(_options.Build(), CancellationToken.None);
                }
                catch
                {
                    Console.WriteLine("Reconnecting to broker failed");
                }
            });
            _client.UseApplicationMessageReceivedHandler(e =>
            {
                Console.WriteLine("### Application Message recived ###");
                Console.WriteLine($"+ Topic = {e.ApplicationMessage.Topic}");
                Console.WriteLine($"+ Payload = {Encoding.UTF8.GetString(e.ApplicationMessage.Payload)}");
                Console.WriteLine($"+ QoS = {e.ApplicationMessage.QualityOfServiceLevel}");
                Console.WriteLine($"+ Retain = {e.ApplicationMessage.Retain}");
                Console.WriteLine();
                
            });
            return _client;
        }

        //This method sends messages to topic "test"
        public MqttApplicationMessage SimulatePublish(IMqttClient mqttClient = null, string val = null)
        {
            _client = _client == null ? mqttClient : _client;
            var testMessage = new MqttApplicationMessageBuilder()
                .WithTopic("test")
                .WithPayload(val)
                .WithExactlyOnceQoS()
                .WithRetainFlag()
                .Build();

            if (_client.IsConnected)
            {
                //Console.WriteLine($"publishing at {DateTime.UtcNow}");
                _client.PublishAsync(testMessage);
            }
            Thread.Sleep(millisecondsTimeout: 2000);
            return testMessage;
        }
    }

}
